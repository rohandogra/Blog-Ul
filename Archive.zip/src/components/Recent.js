import React from 'react'
import axios from 'axios'

class Recent extends React.Component {
  constructor() {
    super()
    this.state = {
      posts: [],
      recent: []
    }
  }
  componentDidMount() {
    axios.get(`http://jsonplaceholder.typicode.com/posts`).then(response => {
      const posts = response.data
      this.setState({
        posts,
        recent: posts.slice(posts.length - 5, posts.length)
      })
    })
  }
  render() {
    return (
      <div>
        <h2>Recent Posts - {this.state.recent.length}</h2>
        <ul>
          {this.state.recent.map(post => {
            return <li key={post.id}>{post.title}</li>
          })}
        </ul>
      </div>
    )
  }
}

export default Recent
