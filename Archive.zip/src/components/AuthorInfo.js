import React from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

class AuthhorInfo extends React.Component {
  constructor() {
    super()
    this.state = {
      users: {},
      posts: []
    }
  }
  componentDidMount() {
    const id = this.props.match.params.id
    axios
      .get(`http://jsonplaceholder.typicode.com/users/${id}`)
      .then(response => {
        const users = response.data
        this.setState({
          users
        })
      })

    axios
      .get(`http://jsonplaceholder.typicode.com/posts?userId=${id}`)
      .then(response => {
        const posts = response.data
        this.setState({
          posts
        })
      })
  }
  render() {
    return (
      <div>
        <h2>Author: {this.state.users.name}</h2>
        <h3>Email: {this.state.users.email} </h3>
        <ul>
          <h4>Listing Posts written by - {this.state.users.name}</h4>
          {this.state.posts.map(post => {
            return (
              <li key={post.id}>
                <Link to={`/posts/${post.id}`}>{post.title}</Link>
              </li>
            )
          })}
        </ul>
        <Link to="/">Back</Link>
      </div>
    )
  }
}

export default AuthhorInfo
