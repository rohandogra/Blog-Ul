import React from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

class Posts extends React.Component {
  constructor() {
    super()
    this.state = {
      posts: [],
      morePosts: []
    }
  }
  componentDidMount() {
    axios.get(`http://jsonplaceholder.typicode.com/posts`).then(response => {
      const posts = response.data
      this.setState({ posts, morePosts: posts.slice(0, 10) })
    })
  }
  handleLoad = () => {
    this.setState(prevState => ({
      morePosts: prevState.posts.slice(0, prevState.morePosts.length + 10)
    }))
  }
  render() {
    return (
      <div>
        <h2>Listing Posts {this.state.morePosts.length}</h2>
        <ol>
          {this.state.morePosts.map(post => {
            return (
              <li key={post.id}>
                <Link to={`/posts/${post.id}`}>{post.title}</Link>
              </li>
            )
          })}
        </ol>
        <button onClick={this.handleLoad}>Load More</button>
        <br />
        <br />
        <Link to="/">back</Link>
      </div>
    )
  }
}

export default Posts
