import React from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
class PostInfo extends React.Component {
  constructor() {
    super()
    this.state = {
      users: {},
      posts: {},
      comments: []
    }
  }
  componentDidMount() {
    const id = this.props.match.params.id
    axios
      .get(`http://jsonplaceholder.typicode.com/posts/${id}`)
      .then(response => {
        const posts = response.data
        this.setState({
          posts
        })
        axios
          .get(
            `http://jsonplaceholder.typicode.com/users/${this.state.posts.userId}`
          )
          .then(response => {
            const users = response.data
            this.setState({
              users
            })
          })
        axios
          .get(
            `http://jsonplaceholder.typicode.com/comments?postId=${this.state.posts.id}`
          )
          .then(response => {
            const comments = response.data
            this.setState({
              comments
            })
          })
      })
  }
  render() {
    return (
      <div>
        <h1>Author: {this.state.users.name}</h1>
        <p>
          <b>Title</b>:{this.state.posts.title}
        </p>
        <p>
          <b>Body</b>: {this.state.posts.body}
        </p>
        <ul>
          <h3>Listing Comments</h3>
          {this.state.comments.map(comm => {
            return <li key={comm.name}>{comm.name}</li>
          })}
        </ul>
        <Link to="/">Back</Link>
      </div>
    )
  }
}

export default PostInfo
