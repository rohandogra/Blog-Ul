import React from 'react'
import { BrowserRouter, Route, Link } from 'react-router-dom'

import Posts from './components/Posts'
import Author from './components/Author'
import AuthorInfo from './components/AuthorInfo'
import PostsInfo from './components/PostsInfo'
import Recent from './components/Recent'

function App() {
  return (
    <BrowserRouter>
      <div>
        <h1>Hello Main Page</h1>
        <Link to="/">Home</Link> <Link to="/posts">Posts</Link>{' '}
        <Link to="/author">Authors</Link>
        <Route path="/posts" component={Posts} exact={true} />
        <Route path="/author" component={Author} exact={true} />
        <Route path="/author/:id" component={AuthorInfo} />
        <Route path="/posts/:id" component={PostsInfo} />
        <Recent />
      </div>
    </BrowserRouter>
  )
}

export default App
